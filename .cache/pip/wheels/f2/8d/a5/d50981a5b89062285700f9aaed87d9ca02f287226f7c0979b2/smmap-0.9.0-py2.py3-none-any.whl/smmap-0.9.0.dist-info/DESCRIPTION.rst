See http://github.com/Byron/smmap


